#ifndef BD37534FV_H

#define BD37534FV_H
#define BD37534FV_address 0b1000000 
#define SETUP_1        0x01
#define SETUP_2        0x02
#define SETUP_3        0x03
#define INPUT_SELECT   0x05
#define INPUT_GAIN     0x06
#define VOLUME_GAIN    0x20
#define FADER_1_FRONT  0x28
#define FADER_2_FRONT  0x29
#define FADER_1_REAR   0x2A
#define FADER_2_REAR   0x2B
#define FADER_SUB      0x2C
#define BASS_SETUP     0x41
#define MIDDLE_SETUP   0x44
#define TREBLE_SETUP   0x47
#define BASS_GAIN      0x51
#define MIDDLE_GAIN    0x54
#define TREBLE_GAIN    0x57
#define LOUDNESS_GAIN  0x75
#define MIXING         0x30
#define RESET          0xFE

#include <Arduino.h>
class BD37534FV
{
  public:
    BD37534FV();
      void setSetup_1(int8_t sw_of, int8_t sw_time, int8_t time_mute); // default (1,2,0)
        // sw_of = OFF ON = int8_t 0...1 (1 default)
        // sw_time = 4.7msec 7.1msec 11.2msec 14.4msec = int8_t 0...3 (2 default) 
        // time_mute = 0.6msec 1.0msec 1.4msec 3.2msec = int8_t 0...3 (0 default) 
      void setSetup_2(int8_t sub_f, int8_t sub_out, int8_t level_metr, int8_t faza); 
        // sub_f = OFF 55Hz 85Hz 120Hz 160Hz = int8_t 0...4
        // sub_out = LPF Front Rear Prohibition = int8_t 0...3
        // level_metr = HOLD REST = int8_t 0...1
        // faza = 0 180 = int8_t 0...1
      void setLoudness_f(int8_t loud_f); // loud_f = 250Hz 400Hz 800Hz Prohibition = int8_t 0...3
      void setIn(int8_t in); // in = 0...6 = int8_t 0...6
      void setIn_gain(int8_t in_gain, int8_t mute); 
        // in_gain = 0...20 dB = int8_t 0...20 --- mute = OFF ONN = int8_t 0...1 (0 default)
      void setVol(int vol); // -79...+15 dB = int -79...15
      void setFront_1(int front_1); // -79...+15 dB = int -79...15
      void setFront_2(int front_2); // -79...+15 dB = int -79...15
      void setRear_1(int rear_1); // -79...+15 dB = int -79...15
      void setRear_2(int rear_2); // -79...+15 dB = int -79...15
      void setSub(int sub); // -79...+15 dB = int -79...15
      void setBass_setup(int8_t bass_q, int8_t bass_f); 
        // bass_q = 0.5 1.0 1.5 2.0 = int8_t 0...3 --- bass_f = 60Hz 80Hz 100Hz 120Hz = int8_t 0...3
      void setMiddle_setup(int8_t mid_q, int8_t mid_f); 
        // mid_q = 0.75 1.0 1.25 1.5 = int8_t 0...3 --- mid_f = 500Hz 1kHz 1.5kHz 2.5kHz = int8_t 0...3
      void setTreble_setup(int8_t treb_q, int8_t treb_f); 
        // treb_q = 0.75 1.25 = int8_t 0...1 --- treb_f = 7.5kHz 10kHz 12.5kHz 15kHz = int8_t 0...3
      void setBass_gain(int bass_gain); // -20...+20 dB = int -20...20    
      void setMiddle_gain(int mid_gain); // -20...+20 dB = int -20...20
      void setTreble_gain(int treb_gain); // -20...+20 dB = int -20...20        
      void setLoudness_gain(int8_t loud_gain); // loud_gain = 0...20 dB = int8_t 0...20 
      void mix();
      void System_Reset();
  private:
      void writeWire(int8_t a, int8_t b);
};
    
#endif //BD37534FV_H
